from setuptools import setup, find_packages

setup(
    name = "hello-world-sammy1988",
    version = "0.0.1",
    author = "sam",
    author_email = "test@gmail.com",
    descritpion = "hello-world",
    packages=find_packages(),
    classifiers=[
        "Programming Langugage :: Python :: 3"
    ]
)