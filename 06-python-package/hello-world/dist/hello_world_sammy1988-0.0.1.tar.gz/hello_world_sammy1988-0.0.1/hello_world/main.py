def (x,y):
  return x+y